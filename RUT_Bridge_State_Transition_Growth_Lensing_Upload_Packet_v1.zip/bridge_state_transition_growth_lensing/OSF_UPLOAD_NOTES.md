# OSF Upload Notes

Recommended OSF folder:

```text
RUT Results / Bridge-State Transition Growth-Lensing Test
```

Upload these files together:

1. RUT_Bridge_State_Transition_Growth_Lensing_Report_v1.pdf
2. README.md
3. MANIFEST.md
4. RUT_final_prejournal_parameter_robustness_scan_summary.csv
5. RUT_final_prejournal_ablation_control_summary.csv
6. RUT_final_prejournal_bridge_split_EG_real_input_template.csv
7. RUT_realdata_SDSS_eBOSS_fs8_growth_check_summary.csv
8. RUT_realdata_legacy_EG_check_summary.csv
9. RUT_realdata_combined_fs8_EG_comparison_summary.csv

Suggested OSF description:

This packet documents a bridge-state transition diagnostic for Reverse Universe Theory (RUT). The model predicts that |Delta E_G| follows bridge activation B(a), while |d(Delta E_G)/da| peaks near the bridge transition dB/da. The package includes a 1-page report, robustness summary, ablation-control summary, bridge input template, and first-pass comparisons with compressed f_sigma8 and legacy E_G measurements. These results are preliminary and intended for reproducibility, review, and further covariance-aware testing.
