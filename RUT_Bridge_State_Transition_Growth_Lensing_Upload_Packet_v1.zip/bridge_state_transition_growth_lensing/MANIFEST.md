# Manifest

| File | Size bytes | SHA256 prefix |
|---|---:|---|
| GITHUB_COMMIT_MESSAGE.txt | 350 | `73000aeda8b6325f` |
| OSF_UPLOAD_NOTES.md | 1121 | `515d32c7b2282081` |
| README.md | 2498 | `1f5ceafbf6b7da60` |
| RUT_Bridge_State_Transition_Growth_Lensing_Report_v1.pdf | 4899 | `3c5550bba9076b32` |
| RUT_final_prejournal_ablation_control_summary.csv | 3565 | `1f250d9811f7c521` |
| RUT_final_prejournal_bridge_split_EG_real_input_template.csv | 285226 | `4c9b57f957d61626` |
| RUT_final_prejournal_parameter_robustness_scan_summary.csv | 534 | `668a2ea6226e92e7` |
| RUT_realdata_SDSS_eBOSS_fs8_growth_check_summary.csv | 222 | `d1b095d3c3b3b06e` |
| RUT_realdata_combined_fs8_EG_comparison_summary.csv | 404 | `5cbdae1f2d3df41d` |
| RUT_realdata_legacy_EG_check_summary.csv | 225 | `ac3da674a7e47b4a` |
