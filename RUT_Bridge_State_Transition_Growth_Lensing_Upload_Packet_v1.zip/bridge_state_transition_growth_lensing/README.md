# RUT Bridge-State Transition Growth-Lensing Test

**Public-facing title:** A Bridge-State Transition Diagnostic for Growth-Lensing Splitting in Reverse Universe Theory  
**Subtitle:** Model-Derived Predictions and First-Pass Comparison with f_sigma8 and E_G Data

## Purpose

This packet documents a focused bridge-state diagnostic for Reverse Universe Theory (RUT). The test asks whether a late-time bridge activation behaves as a state transition in growth-lensing observables:

- |Delta E_G| follows the bridge state B(a)
- |d(Delta E_G)/da| follows the bridge transition template dB/da
- the strongest response window appears near k ~ 0.20-0.30 h/Mpc

This packet should be described as a **model-derived bridge-state diagnostic with first-pass data comparison**, not as final proof of RUT.

## Core bridge settings

```text
z_star = 0.35
a_star = 0.7407
delta_a = 0.03
```

Bridge function:

```text
B(a) = 1/2 [1 + tanh((a-a_star)/delta_a)]
```

Transition template:

```text
dB/da = (1/(2 delta_a)) sech^2((a-a_star)/delta_a)
```

## Main result

The minimal effective response model supports a bridge-state interpretation:

```text
|Delta E_G| ~ B(a)
|d(Delta E_G)/da| ~ dB/da
```

The derivative peak remained close to z ~ 0.340852, near the predicted z_star = 0.35.

## Robustness summary

A 250-trial parameter-prior scan favored the k ~ 0.20-0.30 h/Mpc window:

```text
k=0.20: overall pass rate = 0.744; median C_transition = 0.965125
k=0.30: overall pass rate = 0.804; median C_transition = 0.955704
```

## First-pass data comparison

The compressed f_sigma8 growth-only comparison was approximately neutral. The legacy E_G comparison mildly favored the RUT effective model. Combined f_sigma8 + E_G comparison slightly favored RUT at every tested k, with the best combined result at k=0.30 h/Mpc:

```text
combined Delta chi2 (RUT - LCDM) at k=0.30 = -0.167358
```

## Responsible conclusion

This packet does not claim observational confirmation of RUT. It supports a narrower statement:

> A minimal RUT bridge-state model predicts a persistent E_G offset whose fastest change occurs near the bridge transition. This behavior survives null controls, ablation tests, parameter-prior robustness scans, and remains mildly compatible with first-pass f_sigma8 and E_G comparisons.

## Next recommended step

Run a full covariance-aware comparison using larger E_G, weak-lensing, RSD, and BAO datasets, then update this packet with a formal Methods section and a reproducible notebook.
