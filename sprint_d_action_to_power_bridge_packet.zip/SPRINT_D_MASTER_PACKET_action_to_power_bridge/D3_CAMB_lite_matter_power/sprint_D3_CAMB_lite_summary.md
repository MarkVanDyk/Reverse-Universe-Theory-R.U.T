# RUT Sprint D3 — CAMB-lite Matter Power Bridge

## Purpose

Sprint D3 uses the D2b inverse-matrix response to build a first CAMB-lite matter power comparison:

P_RUT(k,z) vs P_LCDM(k,z)

This is not full CAMB or MGCAMB. It is a diagnostic bridge using:

- frozen RUT/M1a background H(a)
- D2b-derived mu(k,z)
- BBKS-like transfer proxy
- linear growth ODE

## Frozen Background

- z_t = 0.35
- width = 0.03
- dG = -0.159
- H0 = 73.6
- Omega_m = 0.248
- rd = 146.7

## Stage C / D2b Corridor

- mu0 = 0.15
- Sigma0 = 0.1
- k_c = 0.3 h/Mpc
- n = 4.0

## ESZI / Target Zone

- L_ESZI ~ 5.0 Mpc
- k_ESZI ~ 0.2 h/Mpc
- Target zone: k ~ 0.2–0.3 h/Mpc

## Key Results

- Max |Delta P/P| full range = 9.512366e-03
- Max |Delta P/P| target zone = 6.883651e-03
- Verdict = very_small_controlled_power_shift

## Interpretation

Sprint D3 shows whether the D2b-derived response produces a controlled scale-dependent matter-power signature. This is a bridge toward MGCAMB/EFTCAMB, not a replacement for a full Boltzmann-code analysis.
