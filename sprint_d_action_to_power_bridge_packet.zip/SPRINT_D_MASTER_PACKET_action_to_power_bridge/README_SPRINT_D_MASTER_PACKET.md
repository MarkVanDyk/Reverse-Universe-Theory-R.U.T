# RUT Sprint D Master Packet
## Action-to-Corridor-to-Power Bridge

This packet summarizes Sprint D, which extends the Stage C perturbation corridor into a first action-to-power pipeline.

## Frozen Background

- z_t = 0.35
- width = 0.03
- dG = -0.159
- H0 = 73.6
- Omega_m = 0.248
- rd = 146.7

Rule: Frozen Stage C background carried into Sprint D. No background retuning.

## Stage C Corridor Target

- mu0 = 0.15
- Sigma0 = 0.1
- k_c = 0.3 h/Mpc
- n = 4.0
- target zone = k ~ 0.2-0.3 h/Mpc

## Sprint D Chain

- D1: Stage C corridor -> D_RG scaffold
- D1b: regularized bridge-weighted D_RG response
- D2: inverse matrix M_AB^-1 response scaffold
- D2b: forced nonzero phi-chi mixing response
- D3: CAMB-lite P(k,z) bridge
- D3b: early-normalized non-anchored P(k,z) bridge

## D2b Nonzero-Mixing Result

Selected matrix parameters:

{
  "m_phi2": 2.0,
  "m_chi2": 2.0,
  "lambda_mix": 0.05,
  "s_phi": 0.1,
  "s_chi": 0.5,
  "q_scale": 0.01,
  "drg_weight": 0.25,
  "status": "healthy"
}

Selected metrics:

{
  "total_score": 0.0025718938937945406,
  "target_error": 0.00019461932415949437,
  "mean_abs_delta_mu": 0.0014263647417810327,
  "mean_abs_delta_Sigma": 0.0009509098278540135,
  "max_abs_delta_mu": 0.017209631737809206,
  "max_abs_delta_Sigma": 0.011473087825206285,
  "eta_min": 0.9130434782608698,
  "eta_max": 1.0,
  "det_min": 3.9975111111191937,
  "det_bad_count": 0
}

Reviewer-safe interpretation:

Sprint D2b shows that the Stage C perturbation corridor can be reproduced by a stable inverse response matrix with explicit nonzero phase-bridge mixing. This is not a final full derivation from the complete action, but it supports the claim that the corridor can arise from bridge-sector response rather than being merely selected phenomenologically.

## D3b CAMB-lite Matter-Power Result

- Max |Delta P/P| full range = 0.009603720259614867
- Max |Delta P/P| target zone = 0.006931364023212039
- Verdict = very_small_controlled_power_shift

Target-zone summary by redshift:

[
  {
    "z": 0.0,
    "target_P_ratio_min": 1.0045989642853292,
    "target_P_ratio_max": 1.006931364023212,
    "target_DeltaP_mean": 0.005765164154270641,
    "target_DeltaP_absmax": 0.006931364023212039,
    "target_mu_min": 1.027869971665826,
    "target_mu_max": 1.0846069753711614
  },
  {
    "z": 0.35,
    "target_P_ratio_min": 1.0003843125662955,
    "target_P_ratio_max": 1.0004578558091448,
    "target_DeltaP_mean": 0.0004210841877200962,
    "target_DeltaP_absmax": 0.0004578558091448137,
    "target_mu_min": 1.014098042873908,
    "target_mu_max": 1.042722097289598
  },
  {
    "z": 0.5,
    "target_P_ratio_min": 1.0000001643881336,
    "target_P_ratio_max": 1.0000001711601816,
    "target_DeltaP_mean": 1.6777415760375428e-07,
    "target_DeltaP_absmax": 1.7116018158347401e-07,
    "target_mu_min": 1.000001288306198,
    "target_mu_max": 1.0000038810456156
  },
  {
    "z": 1.0,
    "target_P_ratio_min": 1.0,
    "target_P_ratio_max": 1.0,
    "target_DeltaP_mean": 0.0,
    "target_DeltaP_absmax": 0.0,
    "target_mu_min": 1.0,
    "target_mu_max": 1.0
  }
]

Reviewer-safe interpretation:

Sprint D3b removes the present-day normalization anchor and confirms that the D2b inverse-response corridor produces a very small, controlled CAMB-lite matter-power signature. In the target zone k ~ 0.2-0.3 h/Mpc, the signal is a sub-1% late-time enhancement. This is not full CAMB/MGCAMB; it is a bridge result that motivates a proper Boltzmann-code implementation.

## Conservative Overall Verdict

Sprint D provides a first action-to-power bridge for RUT/M1a. The Stage C corridor is no longer only a phenomenological healthy region: it can be approximated by a regularized radiation-gravity response, then by a stable inverse matrix response with nonzero phase-bridge mixing, and finally propagated into a CAMB-lite matter-power signature. This is not a full derivation from the complete action and not a full Boltzmann-code result. It is a reviewer-facing derivation scaffold that motivates MGCAMB/EFTCAMB implementation.

## Next Step

Sprint D4 should either map the D2b response into an MGCAMB/EFTCAMB-style mu/Sigma parameter file, or compare the CAMB-lite P(k,z) ratio against compressed DESI/Euclid-like observational constraints.
