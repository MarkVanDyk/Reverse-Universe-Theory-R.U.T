# RUT Sprint D2 — Inverse-Matrix Response Extraction

## Purpose

Sprint D2 replaces the D1b normalized response scaffold with an explicit minimal inverse field-response matrix.

The model uses a two-field perturbation system:

- delta_phi: phase-field ripple
- delta_chi: bridge-field ripple

M_AB(k,a) =
[[q + m_phi^2, lambda_mix B(a)],
 [lambda_mix B(a), q + m_chi^2]]

with q = q_scale (k/k_c)^2 / a^2.

The response is:

delta_varphi_A = M_AB^-1 S_B

## Frozen Background

- z_t = 0.35
- width = 0.03
- dG = -0.159
- H0 = 73.6
- Omega_m = 0.248
- rd = 146.7

## Stage C Corridor Target

- mu0 = 0.15
- Sigma0 = 0.1
- k_c = 0.3 h/Mpc
- n = 4.0

## Best Matrix Parameters

{
  "m_phi2": 1.0,
  "m_chi2": 1.0,
  "lambda_mix": 0.0,
  "s_phi": 0.25,
  "s_chi": 1.0,
  "q_scale": 0.01,
  "drg_weight": 0.5
}

## Best Metrics

{
  "total_score": 0.002965465953906739,
  "target_error": 0.000759108612594975,
  "mean_abs_delta_mu": 0.001323814404787056,
  "mean_abs_delta_Sigma": 0.0008825429365247081,
  "max_abs_delta_mu": 0.017209631737809206,
  "max_abs_delta_Sigma": 0.011473087825206285,
  "eta_min": 0.9130434782608698,
  "eta_max": 1.0,
  "det_min": 1.0000055555632716,
  "det_bad_count": 0
}

## Verdict

strong_first_pass_matrix_match

## Interpretation

This is not yet a final proof from the full action. It is an effective derivation scaffold showing that a simple M_AB inverse response can approximate the Stage C corridor. The next step is to use this D2-derived mu/Sigma response in a CAMB-lite matter power bridge.
