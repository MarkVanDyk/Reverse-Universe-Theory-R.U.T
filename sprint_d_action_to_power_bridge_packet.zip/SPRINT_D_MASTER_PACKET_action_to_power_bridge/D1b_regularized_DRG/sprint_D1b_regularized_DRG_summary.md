# RUT Sprint D1b — Regularized D_RG Scaffold

## Purpose

D1 produced a useful action-to-corridor scaffold, but the raw radiation-gravity diagnostic D_RG exploded when the bridge was off or the gravitational proxy denominator became tiny.

D1b regularizes the diagnostic and compares response variants.

## Frozen Background

- z_t = 0.35
- width = 0.03
- dG = -0.159
- H0 = 73.6
- Omega_m = 0.248
- rd = 146.7

## Stage C Corridor

- mu0 = 0.15
- Sigma0 = 0.1
- k_c = 0.3 h/Mpc
- n = 4.0

## D_RG Regularization

Raw D_RG range:

- min = 6.989247e-05
- max = 5.208333e+31

Regularized D_RG range:

- min = 6.989003e-05
- max = 1.086062e+01

Bridge-weighted D_RG range:

- min = 0.000000e+00
- max = 5.653067e-01

## Variant Scores

Best variant: bw

variant  max_abs_delta_mu  max_abs_delta_Sigma  mean_abs_delta_mu  mean_abs_delta_Sigma  mu_min  mu_max  Sigma_min  Sigma_max  eta_min  eta_max  total_mean_error
     bw          0.017210             0.011473           0.001438              0.000958     1.0    1.15        1.0        1.1 0.913043      1.0          0.002396
  clean          0.017210             0.011473           0.001438              0.000958     1.0    1.15        1.0        1.1 0.913043      1.0          0.002396
    reg          0.028431             0.018954           0.002329              0.001553     1.0    1.15        1.0        1.1 0.913043      1.0          0.003882

## Interpretation

D1b makes the radiation-gravity diagnostic numerically safer. It does not yet derive the perturbation response from the action. It identifies which response profile D2 should reproduce using an inverse field-response matrix.

## Next Step

Sprint D2 should construct a 2x2 or 3x3 M_AB(k,a) response matrix whose inverse generates the selected response profile and maps to mu0 and Sigma0.
