# RUT Sprint D3b — Early-Normalized CAMB-lite Matter Power Bridge

## Purpose

D3 normalized growth to D(z=0)=1, anchoring the z=0 matter-power ratio to unity.

D3b instead normalizes at early time:

D(a_ini)=1

This tests whether the D2b-derived response produces a non-anchored matter-power signature.

## Frozen Background

- z_t = 0.35
- width = 0.03
- dG = -0.159
- H0 = 73.6
- Omega_m = 0.248
- rd = 146.7

## Corridor and Target Zone

- mu0 = 0.15
- Sigma0 = 0.1
- k_c = 0.3 h/Mpc
- n = 4.0
- ESZI target zone: k ~ 0.2–0.3 h/Mpc

## Key Results

- Max |Delta P/P| full range = 9.603720e-03
- Max |Delta P/P| target zone = 6.931364e-03
- Verdict = very_small_controlled_power_shift

## Interpretation

D3b checks whether the D3 signal was an artifact of present-day normalization. This is still CAMB-lite, not a full Boltzmann-code calculation.
