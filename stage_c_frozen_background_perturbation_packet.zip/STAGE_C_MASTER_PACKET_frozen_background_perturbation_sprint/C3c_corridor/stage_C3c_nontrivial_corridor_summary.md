# RUT Stage C3c — Nontrivial Healthy Perturbation Corridor

## Purpose

Stage C3c filters the Stage C3b stress scan to exclude the pure GR/no-modification limit and identify nontrivial but healthy k-dependent perturbation regions.

## Counts

- Total C3b combinations: 270
- Healthy total: 213
- Healthy nontrivial combinations: 204
- Reviewer-safe corridor combinations: 98

## C3a Reference Point

- mu0 = 0.15
- Sigma0 = 0.05
- k_c = 0.10 h/Mpc
- n_k = 2.0
- status = healthy
- health flags = healthy_first_pass

## Safe Corridor Summary

{
  "mu0_min": -0.3,
  "mu0_max": 0.3,
  "Sigma0_min": -0.2,
  "Sigma0_max": 0.2,
  "k_c_values": [
    0.03,
    0.1,
    0.3
  ],
  "n_k_values": [
    1.0,
    2.0,
    4.0
  ],
  "eta_min_global": 0.7600000000155294,
  "eta_max_global": 1.2352941176267045,
  "max_mu_deviation_global": 0.1499999999889705,
  "max_Sigma_deviation_global": 0.1499999999889705
}

## Interpretation

Stage C3c identifies candidate nontrivial perturbation corridors for future k-binned observational tests. This is not an empirical evidence claim. It is a mathematical and phenomenological health screen.
