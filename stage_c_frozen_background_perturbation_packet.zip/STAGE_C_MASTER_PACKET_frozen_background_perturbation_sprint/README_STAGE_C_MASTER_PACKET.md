# RUT Stage C Master Packet  
## Frozen-Background Perturbation Sprint

This packet summarizes Stage C of the RUT/M1a frozen-background perturbation pipeline.

## Frozen Background Parameters

- z_t = 0.35
- width = 0.03
- dG = -0.159
- H0 = 73.6
- Omega_m = 0.248
- rd = 146.7

Rule: Frozen background. No refitting of H0, Omega_m, rd, z_t, width, or dG during Stage C primary tests.

## Stage C1 — fσ8 Growth Survival

The frozen M1a background was tested against RSD fσ8 growth data without retuning background parameters.

Result: weak / near-tied support for M1a. The main value of this result is survival, not strong evidence.

Key numbers:

- M1a chi2 = 5.336830
- M1a BIC = 7.128589
- M1a reduced chi2 = 1.067366
- LCDM chi2 = 5.572831
- LCDM BIC = 7.364590
- Delta BIC = BIC(M1a) - BIC(LCDM) = -0.236001

## Stage C1b — Robustness

- Total checks: 10
- M1a-favoring checks: 10
- LCDM-favoring checks: 0
- Delta BIC range: -0.328238 to -0.020819

Interpretation: the growth result is weak but stable; no leave-one-out or subset check favored LCDM.

## Stage C2a — E_G / Lensing Consistency

- E_G points: 2
- LCDM chi2 = 0.094109
- M1a chi2 = 0.115535
- Delta BIC = 0.021427

Interpretation: statistically tied. This is a compatibility/survival result, not evidence favoring M1a.

## Stage C3 — k-Dependent Perturbation Health

C3a-C3c tested whether a nontrivial k-dependent perturbation sector can remain mathematically healthy.

- C3a health flags: healthy_first_pass
- C3b total combinations: 270
- C3b healthy: 213
- C3b warnings: 57
- C3b fails: 0
- C3b healthy fraction: 0.788889
- C3c healthy nontrivial combinations: 204
- C3c reviewer-safe corridor combinations: 98

Top nontrivial corridor:

- mu0 = 0.15
- Sigma0 = 0.1
- k_c = 0.3
- n_k = 4.0
- eta range = 0.9534883720962044 to 1.0
- mu range = 1.0 to 1.0749999999944853
- Sigma range = 1.0 to 1.0499999999963234

Interpretation: Stage C3 passes as a nontrivial perturbation health screen. This is not an observational evidence claim until k-binned data are fitted.

## Conservative Overall Verdict

Stage C is best described as a frozen-background survival and perturbation-health result.

The model did not produce a smoking-gun observational win in Stage C. However, it also did not collapse under growth, E_G/lensing consistency, or k-dependent perturbation health checks.

Reviewer-safe claim:

> The frozen M1a background survives preliminary growth and lensing consistency tests and supports a nontrivial, mathematically healthy k-dependent perturbation corridor. These results motivate future k-binned observational tests with matched parameter counting.

## Next Step

Upload this packet to GitHub and OSF, then run the next empirical extension using k-binned growth/lensing data or compressed modified-gravity constraints.
