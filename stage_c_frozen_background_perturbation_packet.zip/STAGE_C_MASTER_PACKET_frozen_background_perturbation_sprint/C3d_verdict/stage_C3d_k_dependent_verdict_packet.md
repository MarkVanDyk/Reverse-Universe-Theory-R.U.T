# RUT Stage C3d — k-Dependent Perturbation Verdict Packet

## Frozen Background Parameters

- z_t = 0.35
- width = 0.03
- dG = -0.159
- H0 = 73.6
- Omega_m = 0.248
- rd = 146.7

Rule: background parameters remain frozen. Stage C3 tests perturbation-sector health only.

## Stage C3a — Reference k-Dependent Diagnostic

Health flags:

- healthy_first_pass

Ranges:

- mu range: 1.0 to 1.1349999999900735
- Sigma range: 1.0 to 1.0449999999966912
- eta range: 0.84140969164023 to 1.0
- E_G proxy range: 0.2732550696426444 to 0.5559705749215339

Interpretation: the reference k-dependent perturbation grid produced no obvious mathematical instability.

## Stage C3b — Stress Scan

Counts:

- Total combinations: 270
- Healthy: 213
- Warning: 57
- Fail: 0
- Healthy fraction: 0.7888888888888889

Verdict:

Stage C3b passes: broad parameter scan has no hard failures and a healthy core region.

Interpretation: the perturbation ansatz has a broad healthy region and no hard failures in the scanned range.

## Stage C3c — Nontrivial Healthy Corridor

Counts:

- Healthy nontrivial combinations: 204
- Reviewer-safe corridor combinations: 98

C3a reference point:

- mu0 = 0.15
- Sigma0 = 0.05
- k_c = 0.1
- n_k = 2.0
- status = healthy
- health flags = healthy_first_pass

Top nontrivial corridor point:

- mu0 = 0.15
- Sigma0 = 0.1
- k_c = 0.3
- n_k = 4.0
- eta range = 0.9534883720962044 to 1.0
- mu range = 1.0 to 1.0749999999944853
- Sigma range = 1.0 to 1.0499999999963234

## Conservative Interpretation

Stages C3a-C3c show that the frozen-background RUT perturbation ansatz has a broad, nontrivial, mathematically healthy k-dependent corridor. This supports internal consistency and motivates future k-binned observational tests.

This should not be presented as direct observational evidence until k-dependent data are fitted.

## Next Empirical Step

Add k-binned growth/lensing data or compressed constraints and run a matched ΛCDM-vs-M1a k-dependent likelihood with equal parameter counting.
