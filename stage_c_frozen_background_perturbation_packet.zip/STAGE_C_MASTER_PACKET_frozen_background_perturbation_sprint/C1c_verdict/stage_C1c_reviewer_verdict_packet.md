# RUT Stage C1/C1b Frozen-Background Growth Verdict

## Frozen Background Parameters

- z_t = 0.35
- width = 0.03
- dG = -0.159
- H0 = 73.6
- Omega_m = 0.248
- rd = 146.7

Background parameters were frozen. Only sigma8 was fitted in the primary no-mu0 growth tests.

## Primary Stage C1 Result

M1a frozen background:

- chi2 = 5.336830
- BIC = 7.128589
- reduced chi2 = 1.067366
- sigma8 = 0.856916
- S8 = 0.779118

LCDM fixed Omega_m comparison:

- chi2 = 5.572831
- BIC = 7.364590
- reduced chi2 = 1.114566
- sigma8 = 0.858357
- S8 = 0.780429

Matched-pair Delta BIC:

- Delta BIC = BIC(M1a) - BIC(LCDM) = -0.236001

## Stage C1b Robustness Result

- Total robustness checks: 10
- M1a weakly favored checks: 10
- Roughly tied checks: 0
- LCDM-favored checks: 0
- Delta BIC range: -0.328238 to -0.020819

## Conservative Interpretation

The frozen M1a background survives the independent fσ8 growth test without retuning. The Delta BIC values are small and should not be presented as strong evidence. However, the result is robust under leave-one-out and subset diagnostics, with no check favoring LCDM.

## Next Stage

Stage C2 should test E_G / lensing consistency, followed by k-dependent perturbation diagnostics.
