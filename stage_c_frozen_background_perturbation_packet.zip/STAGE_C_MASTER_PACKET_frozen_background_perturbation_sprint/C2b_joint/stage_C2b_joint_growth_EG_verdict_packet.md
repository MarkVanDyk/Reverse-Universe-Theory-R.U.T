# RUT Stage C2b — Joint fσ8 + E_G Preliminary Verdict

## Frozen Background Parameters

- z_t = 0.35
- width = 0.03
- dG = -0.159
- H0 = 73.6
- Omega_m = 0.248
- rd = 146.7

Rule: Background parameters frozen from Stage A/M1a. No background retuning allowed.

## Stage C1 Growth Block

M1a frozen background:

- chi2 = 5.336830
- BIC = 7.128589
- reduced chi2 = 1.067366
- sigma8 = 0.856916
- S8 = 0.779118

LCDM comparison:

- chi2 = 5.572831
- BIC = 7.364590
- reduced chi2 = 1.114566

Growth ΔBIC = BIC(M1a) - BIC(LCDM) = -0.236001

## Stage C2a E_G Block

No-new-parameter E_G comparison:

- LCDM chi2 = 0.094109
- M1a chi2 = 0.115535
- ΔBIC = BIC(M1a) - BIC(LCDM) = 0.021427

Interpretation: statistically tied.

## Joint Preliminary Diagnostic

Combined fσ8 + E_G:

- N_joint = 8
- k_joint = 1
- LCDM joint chi2 = 5.666939
- M1a joint chi2 = 5.452365
- LCDM joint BIC = 7.746381
- M1a joint BIC = 7.531806
- ΔBIC = BIC(M1a) - BIC(LCDM) = -0.214574
- M1a reduced chi2 = 0.778909
- LCDM reduced chi2 = 0.809563

Verdict: weakly_favors_M1a / statistically_tied

## Robustness Note

Stage C1b robustness checks:

- Total checks: 10
- M1a weakly favored checks: 10
- LCDM-favored checks: 0
- ΔBIC range: -0.328238 to -0.020819

## Conservative Interpretation

The frozen M1a background survives a preliminary joint growth plus E_G consistency check. The combined ΔBIC is small and should be interpreted as statistically tied or only weakly favorable to M1a. The useful result is that M1a is not penalized by adding E_G/lensing consistency data after the fσ8 growth test.

## Limitations

- This is not a full covariance-aware joint likelihood.
- The E_G block contains only two observed points.
- The E_G errors were symmetrized for this first-pass check.
- This should be described as a preliminary consistency/survival test, not a discovery claim.

## Next Stage

Stage C3 should test k-dependent μ(k,a), Σ(k,a), and η(k,a) diagnostics.
