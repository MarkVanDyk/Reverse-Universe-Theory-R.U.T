# Packet Manifest

## Source packets copied

- `sprint_a_background.zip`
- `sprint_b_growth.zip`
- `sprint_c_dual_channel.zip`
- `sprint_c_pilot_eg.zip`
- `sprint_c_hardening.zip`

## Extracted source files

See `MANIFEST.csv` for a machine-readable list.
