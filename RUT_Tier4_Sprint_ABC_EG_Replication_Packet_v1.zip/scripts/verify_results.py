#!/usr/bin/env python3
"""Verify headline RUT Sprint C-H E_G replication-packet claims.

Run from packet root:
    python scripts/verify_results.py
"""
from pathlib import Path
import pandas as pd

root = Path(__file__).resolve().parents[1]
ch = root / 'data' / 'extracted' / 'sprint_c_hardening'

hardened = pd.read_csv(ch / 'EG_hardened_comparison.csv')
jack = pd.read_csv(ch / 'EG_leave_one_point_out.csv')

print('RUT Sprint C-H verification')
print('=' * 40)

# Fixed neutral-lensing RUT rows by subset
neutral = hardened[hardened['model'] == 'RUT_neutral_lambda_0'].copy()
cols = ['subset', 'n', 'chi2', 'Delta_BIC_vs_LCDM']
print('\nFixed neutral-lensing RUT vs LCDM:')
print(neutral[cols].to_string(index=False))

required_subsets = {
    'full_diagonal_compilation',
    'one_per_family_min_sigma',
    'family_weighted_average',
}
missing = required_subsets.difference(set(neutral['subset']))
if missing:
    raise SystemExit(f'Missing required subset rows: {sorted(missing)}')

for subset in required_subsets:
    delta = float(neutral.loc[neutral['subset'] == subset, 'Delta_BIC_vs_LCDM'].iloc[0])
    if delta >= 0:
        raise SystemExit(f'FAIL: neutral RUT does not beat LCDM for {subset}: Delta BIC={delta}')

win_fraction = jack['neutral_RUT_wins'].astype(bool).mean()
worst_delta = jack['Delta_BIC_neutral_vs_LCDM'].max()
best_delta = jack['Delta_BIC_neutral_vs_LCDM'].min()

print('\nLeave-one-point-out jackknife:')
print(f'Neutral RUT win fraction: {win_fraction:.3f}')
print(f'Worst neutral Delta BIC: {worst_delta:.6f}')
print(f'Best neutral Delta BIC: {best_delta:.6f}')

if win_fraction != 1.0:
    raise SystemExit('FAIL: neutral RUT does not win every leave-one-point-out run.')
if worst_delta >= 0:
    raise SystemExit(f'FAIL: worst jackknife Delta BIC is not negative: {worst_delta}')

print('\nPASS: Headline Sprint C-H claims reproduce from stored CSVs.')
