
# RUT Tier 4 Sprint A+B+C Replication Packet

**Packet title:** RUT Tier 4 Sprint A+B+C Replication Packet - Background, Growth, and Hardened Pilot E_G Tests  
**Prepared for:** Mark Van Dyk / Craft Conscious LLC  
**Packet version:** v1  
**Date:** 2026-05-13  

## Executive summary

This packet collects the outputs from three related testing stages of Reverse Universe Theory (RUT):

1. **Sprint A - Background bridge:** tests the reduced bridge against background observables such as cosmic chronometers and DESI BAO.
2. **Sprint B - Growth gate:** tests whether a simple growth-sector modification improves pilot growth data.
3. **Sprint C / C-H - E_G and lensing gate:** tests whether the growth-lensing relationship, using the E_G diagnostic, is a more favorable lane for RUT.

The most important current result is not that RUT is confirmed. The important result is that the pipeline became testable and produced its first weak, hardened, real-data advantage in the E_G/lensing lane.

The conservative current status is:

> **Tier 4 pipeline with weak but hardened Tier 4-style evidence emerging in the E_G/lensing sector.**

This packet is intended for GitHub and OSF upload as a replication / verification packet. It includes the original Sprint result ZIPs, extracted CSVs, summary reports, a verification script, and an upload guide.

## Model form carried forward

The tested bridge form is:

```text
B(a) = 1/2 [1 + tanh((a - a_t) / Delta a)]
```

The growth and lensing channels are written as:

```text
mu(a) = 1 + mu0 B(a)
Sigma(a) = 1 + lambda_Sigma mu0 B(a)
```

The strongest fixed model in the E_G lane is the **neutral-lensing** case:

```text
lambda_Sigma = 0
Sigma(a) = 1
```

This means growth receives the RUT bridge correction, while lensing is not boosted by the same bridge.

## Sprint A: background bridge result

Sprint A tested whether the reduced RUT background bridge improves real background observables.

**Core conclusion:** Background-only data did not prefer the RUT bridge over LCDM.

Key read:

```text
Reduced RUT bridge real-data fit: beta about 0.1006
Delta chi2 RUT-LCDM: about -0.078
Delta BIC RUT-LCDM: about +3.7
```

Interpretation: the bridge is numerically stable and mock-validated, but current background data prefer LCDM.

## Sprint B: growth / joint result

Sprint B tested growth using pilot f_sigma8 data, then a joint background + growth comparison.

**Core conclusion:** RUT_mu improved raw chi-square slightly, mostly through f_sigma8, but did not beat LCDM by BIC.

Key read:

```text
Joint RUT_mu vs LCDM:
Delta chi2: about -0.476
Delta BIC: about +3.63
Best-fit mu0: about 0.173
Fixed beta: about 0.100586
```

Interpretation: the growth sector shows a mild, stable positive mu0 preference, but it is not yet BIC-supported in the joint test.

## Sprint C: pilot E_G / lensing result

Sprint C tested E_G, a diagnostic that connects growth and lensing. This became the strongest lane for RUT.

### Pilot multi-point E_G result

In the pilot multi-point E_G comparison:

```text
LCDM chi2: about 20.289
RUT neutral chi2: about 18.182
Delta BIC RUT neutral - LCDM: about -2.108
```

The fitted lambda_Sigma model improved raw chi-square further but paid a parameter penalty:

```text
Best-fit lambda_Sigma: about -0.200
Best-fit Sigma0: about -0.0346
Delta BIC lambda-fit - LCDM: about -0.307
```

Interpretation: fixed neutral-lensing RUT is the safer claim than the fitted lambda model.

## Sprint C-H: independence hardening result

Sprint C-H tested whether the E_G advantage survived stricter independence and robustness checks.

The fixed neutral-lensing model survived:

```text
Full diagonal compilation: Delta BIC about -2.108
One-measurement-per-family subset: Delta BIC about -1.926
Family-weighted average subset: Delta BIC about -1.963
Leave-one-point-out jackknife: neutral RUT win fraction = 1.0
Worst jackknife Delta BIC: about -1.266
Best jackknife Delta BIC: about -2.548
```

**Conservative claim:**

> Fixed neutral-lensing RUT beats LCDM in pilot E_G growth-lensing tests across full, family-reduced, family-weighted, and leave-one-point-out comparisons.

## Caveats

This packet does **not** claim that RUT is confirmed.

The E_G result is still pilot-level because:

- the E_G compilation is diagonal-error only,
- some measurements may overlap in survey data or methodology,
- covariance matrices were not fully incorporated,
- the result should be tested on a publication-grade, covariance-clean E_G/lensing subset.

The result is best described as:

> **Weak but hardened pilot evidence in the E_G/lensing lane.**

## What would make this a clean Tier 4 result?

A clean Tier 4 E_G-lane result would require at least one of the following:

1. A covariance-clean E_G comparison still favoring fixed neutral-lensing RUT.
2. A holdout test where the model is frozen before testing on independent data.
3. Independent replication by another researcher using the packet.
4. A stronger threshold such as Delta BIC less than -6 in a clean dataset.

## Replication instructions

### Quick verification

From the packet root, run:

```bash
python scripts/verify_results.py
```

This script checks the stored CSV outputs and verifies the headline Sprint C-H claims:

- fixed neutral RUT beats LCDM in the full diagonal E_G compilation,
- fixed neutral RUT beats LCDM in the one-per-family subset,
- fixed neutral RUT beats LCDM in the family-weighted subset,
- fixed neutral RUT wins all leave-one-point-out jackknife runs.

### Data locations

The original sprint ZIP packets are in:

```text
source_packets/
```

The extracted CSV/result files are in:

```text
data/extracted/
```

The final report and upload instructions are in:

```text
docs/
upload/
```

## Recommended GitHub folder

```text
results/sprint_c_hardened_EG_replication_packet/
```

## Recommended OSF folder

```text
RUT Results / Sprint C-H - E_G Independence Hardening
```

## Recommended commit message

```text
Add Sprint C-H hardened E_G replication packet
```

## Recommended short description

Fixed neutral-lensing RUT beats LCDM in a pilot E_G growth-lensing comparison across the full diagonal compilation, one-per-family subset, family-weighted subset, and leave-one-point-out jackknife checks. This is a hardened pilot result, not a covariance-clean detection claim.
