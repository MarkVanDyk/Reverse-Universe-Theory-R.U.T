
# GitHub and OSF Upload Guide

## GitHub upload

Recommended repository folder:

```text
results/sprint_c_hardened_EG_replication_packet/
```

Upload either:

1. the full replication packet ZIP, or
2. the extracted packet contents as folders/files.

Recommended commit message:

```text
Add Sprint C-H hardened E_G replication packet
```

Recommended commit description:

```text
Adds Sprint A/B/C result packets, extracted CSV outputs, report, and verification script for the RUT Tier 4 Sprint C-H E_G independence hardening result. Fixed neutral-lensing RUT beats LCDM across full diagonal, one-per-family, family-weighted, and leave-one-point-out pilot E_G checks. This is a hardened pilot result, not a covariance-clean detection claim.
```

## OSF upload

Recommended OSF folder:

```text
RUT Results / Sprint C-H - E_G Independence Hardening
```

Upload:

- the full packet ZIP,
- the PDF report,
- optionally the extracted CSVs.

Suggested OSF description:

```text
This packet contains the RUT Tier 4 Sprint C-H E_G independence hardening result. It includes Sprint A/B/C source packets, extracted results tables, a technical report, and a verification script. The central pilot result is that fixed neutral-lensing RUT beats LCDM in E_G comparisons across the full diagonal compilation, one-per-family subset, family-weighted subset, and all leave-one-point-out jackknife checks. This is a hardened pilot result and not yet a covariance-clean detection claim.
```

## Do not upload

Do not upload any passwords, API tokens, private credentials, or personal login information.
